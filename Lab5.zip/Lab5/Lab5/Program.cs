﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenidos a Krusty Burgers");
            //Crear un menú de un restaruante para despachar pedidos
            //Items: Hamburguesas, agua, helado, papas, pizza, postres y pastas
            //mostrar el menú
            //Ordenar
            //pago
            //Variables
            bool continuar = false;
            string cont = "";
            int opcionmenu = 0;
            int menu1 = 0, menu2 = 0, menu3=0, menu4=0, menu5=0, menu6=0, menu7 = 0;
            Console.WriteLine("El menú es: ");
            Console.Write("\n1. Hamburguesas de Lomito");
            Console.Write("\n2. Pasta al pesto");
            Console.Write("\n3. Pizza de pepperoni");
            Console.Write("\n4. Postres - Pastel de Triple Chocolate");
            Console.Write("\n5. Helado - Galleta");
            Console.Write("\n6. Papas fritas con queso");
            Console.Write("\n7. Bebidas");
            try
            {
                do
                {
                    Console.Write("\n Escriba que opción desea ordenar: ");
                    opcionmenu = int.Parse(Console.ReadLine());
                    switch (opcionmenu)
                    {
                        case 1:
                            menu1 = menu1 + 1;
                            break;
                        case 2:
                            menu2 = menu2 + 1;
                            break;
                        case 3:
                            menu3 = menu3 + 1;
                            break;
                        case 4:
                            menu4 = menu4 + 1;
                            break;
                        case 5:
                            menu5 = menu5 + 1;
                            break;
                        case 6:
                            menu6 = menu6 + 1;
                            break;
                        case 7:
                            menu7 = menu7 + 1;
                            break;
                        default:
                            Console.Write("\nPor favor ingrese un número del al 7");
                            break;
                    }
                     Console.Write("Desesa agregar algo más si/no: ");
                            cont = Console.ReadLine();
                     if (cont == "si")
                            {
                                continuar = true;
                            }
                     else
                            {
                                continuar = false;
                            }
                    
                } while (continuar == true);
            }
            catch
            {
                Console.WriteLine("Ha ocurrido un error por favor reinicie el programa.");
            }
            menu1 = menu1 * 150;
            menu2 = menu2 * 100;
            menu3 = menu3 * 90;
            menu4 = menu4 * 30;
            menu5 = menu5 * 30;
            menu6 = menu6 * 20;
            menu7 = menu7 * 15;
            int suma = menu1 + menu2 + menu3 + menu4 + menu5 + menu6 + menu7;
            Console.Write("\n Su total a pagar es: " + suma);
            Console.ReadKey();
        }
    }
}
